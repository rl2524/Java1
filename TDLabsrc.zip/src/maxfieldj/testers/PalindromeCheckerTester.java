package maxfieldj.testers;

import maxfieldj.palindrome1.PalindromeChecker;

/**
 * automate testing for PalindromeChecker.isPalindrome()
 * 2018-10-13
 * @author john maxfield
 */
public class PalindromeCheckerTester {
   private String testStr;                 // a test string
   private boolean testIsA;                // true if test string is a palindrome

   public PalindromeCheckerTester(String testStr, boolean testIsA) {
      this.testStr = testStr;
      this.testIsA = testIsA;
   }

   public static void main(String[] args) {
      PalindromeCheckerTester[] tests = {
          new PalindromeCheckerTester("bob", true),
          new PalindromeCheckerTester("fred", false),
          new PalindromeCheckerTester("Able was I ere I saw Elba", true),
          new PalindromeCheckerTester("Able was I ere I saw Elba.", true),
          new PalindromeCheckerTester("A man, a plan, a canal, Panama", true)
      };
      String isOrIsNot;

      for (PalindromeCheckerTester test : tests) {
         isOrIsNot = test.testIsA ? "is" : "is not";

         if (PalindromeChecker.isPalindrome(test.testStr) == test.testIsA) {
            System.out.println("  OK: '" + test.testStr + "' " + isOrIsNot);
         }
         else {
            System.out.println("FAIL: '" + test.testStr + "' " + isOrIsNot);
         }
      }

   }
}
