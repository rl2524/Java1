package maxfieldj.testers;

/**
 * automate testing for DosEquis.count()
 * 2018-10-13
 * @author john maxfield
 */
public class DosEquisTester {
}
