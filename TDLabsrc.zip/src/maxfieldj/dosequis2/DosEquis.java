package maxfieldj.dosequis2;

public class DosEquis {
   public static int count(String bucket) {
      int count = 0;

      if (bucket == null || bucket.length() <= 1) {
         return 0;
      }

      if ((Character.isLetter(bucket.charAt(0)) && bucket.charAt(0) != 'x')
          && bucket.charAt(0) != 'X' || !Character.isLetter(bucket.charAt(0))) {
         return count(bucket.substring(1, bucket.length()));
      }

      if (bucket.charAt(0) == 'x' && bucket.charAt(1) == 'x') {
         return count(bucket.substring(1, bucket.length()));
      }

      if (bucket.charAt(0) == 'x' && bucket.charAt(1) == 'X') {
         return count(bucket.substring(2, bucket.length()));
      }

      if (bucket.charAt(0) == 'X' && bucket.charAt(1) == 'X') {
         return (count + 1) + count(bucket.substring(2, bucket.length()));
      }

      return count;
   }
}