package maxfieldj.palindrome1;

import java.util.Scanner;

public class PalindromeChecker {

   public static Scanner scnr = new Scanner(System.in);

   public static boolean isPalindrome(String s) {
      s = s.toLowerCase();
      if (s != null) {
         if (s.length() < 2) {
            return true;
         }
         if (s.charAt(0) == ':' ||
             s.charAt(0) == '\'' ||
             s.charAt(0) == ',' ||
             s.charAt(0) == ' ') {
            return isPalindrome(s.substring(1, s.length() - 1));
         }
         if (s.charAt(s.length()-1) == ':' ||
             s.charAt(s.length()-1) == '\'' ||
             s.charAt(s.length()-1) == ',' ||
             s.charAt(s.length()-1) == ' ' ||
             s.charAt(s.length()-1) == '.') {
            return isPalindrome(s.substring(0, s.length() - 1));
         }
         else if (s.charAt(0) == s.charAt(s.length() - 1)) {
            return isPalindrome(s.substring(1, s.length() - 1));
         }
      }
      return false;
   }

   public static void main(String[] args) {
      String userInput;

      System.out.print("Enter a potential palindrome: ");
      userInput = scnr.nextLine();
      System.out.println("That's" + (isPalindrome(userInput) ? "" : " not") + " a palindrome.");
   }
}