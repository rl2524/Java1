package maxfieldj.dosequis1;

public class DosEquis {
   static int count = 0;

   public static int count(String bucket) {

      if (bucket.charAt(0) == 'X' && bucket.charAt(1) == 'X') {
         count++;
         return count(bucket.substring(1, bucket.length()));
      }
      else if (bucket.charAt(0) == 'x' && bucket.charAt(1) == 'X' && bucket.charAt(2) == 'X') {
         count--;
         return count(bucket.substring(1, bucket.length()));
      }
      else if (bucket.charAt(0) == 'X' && bucket.charAt(1) == 'X' && bucket.charAt(2) == 'X') {
         count--;
         return count(bucket.substring(1, bucket.length()));
      }
      else if (bucket.charAt(0) != 'X') {
         return count(bucket.substring(1, bucket.length()));
      }

      return count;
   }
}